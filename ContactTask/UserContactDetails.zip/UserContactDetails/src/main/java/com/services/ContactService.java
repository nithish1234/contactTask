package com.services;

import org.springframework.stereotype.Service;

@Service
public class ContactService {

	public static void addAllContacts(String string) {
		
		
	}

	public void getAllUsers() {
		// TODO Auto-generated method stub
		
	}

}
